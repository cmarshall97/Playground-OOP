from flask import Flask, render_template  

app = Flask(__name__)    

@app.route("/play")
def play():
    return render_template("index.html")*3

@app.route("/play/<int:times>")
def multiply(times):
    return render_template("index.html") *times

@app.route("/play/<int:times>/<color>")
def change_color(times,color):
    return render_template("index.html", color = color) *times

if __name__=="__main__":   
    app.run(debug=True)   